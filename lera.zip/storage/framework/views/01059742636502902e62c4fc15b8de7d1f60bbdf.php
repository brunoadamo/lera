<div class="form-group">
    <label for="clue"><?php echo e(__('Dica')); ?></label>
    

    <div class="card">
        
        <div class="card-body">
             <p class="card-text"><?php echo $narrative->clue; ?></p>
        </div>
    </div>
    
    

</div>



<div class="form-group">
    <?php echo Form::label('content', 'Escreva aqui o ato...', ['class' => 'col-md-12 control-label']); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control summernote', 'placeholder' => 'Escreva aqui o ato...', 'required', 'autofocus']); ?>

    <?php if($errors->has('content')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('content')); ?></p>
    <?php endif; ?>
</div>