<?php

    // $path = $_SERVER['DOCUMENT_ROOT'];

    // $template_path = $path . "resources/views/lib/template/startbootstrap-clean-blog/";
    // die($template_path);
?>    