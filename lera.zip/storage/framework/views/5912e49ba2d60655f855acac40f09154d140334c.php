<!-- Page Header -->
<header class="masthead narrativehead" style="background-image: url('<?php echo e(asset(@$narrative->folder  . '' . @$narrative->picture)); ?>')">
    <div class="overlay"></div>

    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
                <div class="site-heading">
                        <small><strong><?php echo e($narrative->kind->title); ?></strong></small>
                    <h1><?php echo e($narrative->title); ?></h1>
                    <span class="subheading"><?php echo e($narrative->theme); ?></span>
                    <small><strong>Criado por <?php echo e($narrative->user->alias); ?></strong></small>
                    
                </div>
            </div>
        </div>
    </div>
</header>