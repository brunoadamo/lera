<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="post-list">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 mx-auto">

                <h1 class="text-center"><?php echo e(__('Portfólio')); ?></h1><br>

                <?php echo $__env->make('includes._search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('includes._narratives', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                
            </div>
        </div>
    </div>
</div>

<hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>