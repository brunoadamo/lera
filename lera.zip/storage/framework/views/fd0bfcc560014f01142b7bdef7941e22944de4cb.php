<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="profile-content">
    <div class="post-list">
        <div class="container">
            <div class="row">
                
                <div class="col-sm-12 pb-5">
                    <div class="row">
                                   
                        <div class="col-md-4 mx-auto">
                            <img class="img-fluid rounded mb-3 mb-md-0 img-thumbnail mx-auto d-block" src="<?php echo e(asset(@Auth::user()->folder  . '' . @Auth::user()->picture)); ?>" alt="">
                        </div>
                        <div class="col-md-5 text-center">
                            <h2 class="cl-primary">
                                <?php echo e(Auth::user()->name); ?>

                                
                            
                            </h2>
                            <p><strong>Pseudônimo: </strong><?php echo e(Auth::user()->alias); ?></p>
                            <p><strong>E-mail: </strong><?php echo e(Auth::user()->email); ?></p>
                            <p><strong>Narrativas: </strong><?php echo e(count(Auth::user()->narratives)); ?></p>
                            <p><strong>Colaborações: </strong><?php echo e(count(Auth::user()->acts)); ?></p>
                        </div>
                        <div class="col-md-3 ">

                            <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger btn-sm font-weight-normal mx-auto d-block" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> Sair </a>

                            <a href="<?php echo e(url("/admin/users/" . Auth::user()->id . "/edit")); ?>" class="btn btn-info btn-sm font-weight-normal mt-3 mx-auto d-block"> Editar </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>    
               
                <div class="user-narratives col-sm-12 mx-auto">

                    <h3 class="text-center pb-4"><?php echo e(__('Minhas Narrativas')); ?></h3>
                    
                    <div class="row">
                        <div class="col-sm-12 text-center center-block mx-auto pb-4">
                            <a href="<?php echo e(url('admin/narratives/create')); ?>" class="btn btn-warning ">Criar narrativa</a>
                        </div>
                    </div>
                    

                    <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $narratives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $narrative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item">
                            <div class="card h-100">
                                
                                <div class="card-body">
                                    <small> <strong><?php echo e($narrative->kind->title); ?></strong> - <?php echo e($narrative->acts_count); ?> / <?php echo e($narrative->act_n); ?> Atos </small>
                                    <p class="card-text"><a href="/narrative/<?php echo e($narrative->id); ?>"><?php echo e($narrative->title); ?></a></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-sm-12 mx-auto text-center p-4">
                            <p>Nenhuma narrativa cadastrada</p>
                        </div>
                    <?php endif; ?>
                    </div>
        
                </div>
                <div class="user-collaborative-narratives col-sm-12 mx-auto">

                    <h3 class="text-center"><?php echo e(__('Colaborações')); ?></h3><br>

                    <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $colaborates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $narrative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item">
                            <div class="card h-100">
                                
                                <a href="/narrative/<?php echo e($narrative->id); ?>"><img class="card-img-top img-fluid" src="<?php echo e(asset(@$narrative->folder  . '' . @$narrative->picture)); ?>" alt=""></a>
                                <div class="card-body">
                                    <h5>
                                    <a href="/narrative/<?php echo e($narrative->id); ?>"><?php echo e($narrative->title); ?></a>
                                    </h5>
                                    <p class="card-text"><?php echo e($narrative->kind->title); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-sm-12 mx-auto text-center p-4">
                            <p>Você ainda não colaborou com nenhuma narrativa =(</p>
                            <div class="row">
                                <div class="col-sm-12 text-center center-block mx-auto pb-4">
                                    <a href="<?php echo e(url('/narratives')); ?>" class="btn btn-warning ">Comece agora!</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    </div>
                        
                    <!-- Pagination -->
                    <?php echo e($narratives->links()); ?>

                    <!-- Pagination -->
        
                </div>
            </div>
        </div>
    </div>
</div>

<hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>