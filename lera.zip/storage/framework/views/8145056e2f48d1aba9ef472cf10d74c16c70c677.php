<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 class="text-center"><?php echo e(__('Cadastrar usuário')); ?></h1>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php echo $__env->make('auth._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-warning">
                                <?php echo e(__('Cadastrar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>