<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h1 class="text-center"><?php echo e(__('Nova senha')); ?></h1>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('password.request')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="token" value="<?php echo e($token); ?>">

                    <div class="form-group">
                        <div class="form-group floating-label-form-group controls">
                            <label for="email"><?php echo e(__('E-mail')); ?></label>

                            <input id="email" type="email" placeholder="<?php echo e(__('E-mail')); ?>" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        </div>
                        <?php if($errors->has('email')): ?>
                            <p class="help-block text-danger"><?php echo e($errors->first('email')); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <div class="form-group floating-label-form-group controls">
                            <label for="password"><?php echo e(__('Senha')); ?></label>

                            <input id="password" type="password" placeholder="<?php echo e(__('Senha')); ?>" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>" required autofocus>

                            
                        </div>
                        <?php if($errors->has('password')): ?>
                            <p class="help-block text-danger"><?php echo e($errors->first('password')); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <div class="form-group floating-label-form-group controls">
                            <label for="password-confirm"><?php echo e(__('Confirmar senha')); ?></label>

                            <input id="password-confirm" type="password" placeholder="<?php echo e(__('Senha')); ?>" class="form-control<?php echo e($errors->has('password-confirm') ? ' is-invalid' : ''); ?>" name="password-confirm" value="<?php echo e(old('password-confirm')); ?>" required autofocus>

                            
                        </div>
                        <?php if($errors->has('password-confirm')): ?>
                            <p class="help-block text-danger"><?php echo e($errors->first('password')); ?></p>
                        <?php endif; ?>
                    </div>

                
                    <div class="form-group row">
                        <div class="col-md-12 mx-auto">
                            <button type="submit" class="btn btn-warning">
                                <?php echo e(__('Alterar senha')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>