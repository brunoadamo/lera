<div class="form-group">
    <div class="custom-file">
        <input type="file" class="custom-file-input" id="picture" name="picture">
        <label class="custom-file-label" for="picture">Escolha sua foto...</label>
    </div>
    <?php if($errors->has('picture')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('picture')); ?></p>
    <?php endif; ?>
</div>


<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <?php echo Form::label('name', 'Nome', ['class' => 'col-md-12 control-label']); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Nome', 'required', 'autofocus']); ?>


    </div>
    <?php if($errors->has('name')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('name')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <?php echo Form::label('name', 'Pseudônimo', ['class' => 'col-md-12 control-label']); ?>

        <?php echo Form::text('alias', null, ['class' => 'form-control', 'placeholder' => 'Pseudônimo', 'required', 'autofocus']); ?>


    </div>
    <?php if($errors->has('alias')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('alias')); ?></p>
    <?php endif; ?>
</div>
<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <?php echo Form::label('name', 'E-mail', ['class' => 'col-md-12 control-label']); ?>

        <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'E-mail', 'required', 'autofocus']); ?>


    </div>
    <?php if($errors->has('email')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('email')); ?></p>
    <?php endif; ?>
</div>
<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <?php echo Form::label('name', 'Senha', ['class' => 'col-md-12 control-label']); ?>

        <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Senha', 'required', 'autofocus']); ?>


    </div>
    <?php if($errors->has('password')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('password')); ?></p>
    <?php endif; ?>
</div>
<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <?php echo Form::label('name', 'Confimar senha', ['class' => 'col-md-12 control-label']); ?>

        <?php echo Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Confimar senha', 'required', 'autofocus']); ?>


    </div>
    <?php if($errors->has('password-confirm')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('password-confirm')); ?></p>
    <?php endif; ?>
</div>

