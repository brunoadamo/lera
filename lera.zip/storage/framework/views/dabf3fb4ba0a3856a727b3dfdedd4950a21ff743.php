<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h3 class="text-center font-weight-light"><?php echo e(__('Cadastrar Ato')); ?></h3>
            <h1 class="text-center md-10 mx-auto"><?php echo e($narrative->title); ?></h1>

            <div class="card-body">
                <form method="POST" action="/narrative/<?php echo e($narrative->id); ?>/act" aria-label="<?php echo e(__('Cadastrar ato')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                  
                    <?php echo $__env->make('admin.acts._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="form-group row mb-0">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-warning">
                                <?php echo e(__('Cadastrar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>