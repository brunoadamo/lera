<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h1 class="text-center"><?php echo e(__('Cadastrar Narrativas')); ?></h1>

            <div class="card-body">
                <?php echo Form::open(['url' => '/admin/narratives', 'enctype' => 'multipart/form-data', 'role' => 'form']); ?>


                    <?php echo $__env->make('admin.narratives._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="form-group row mb-0">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-warning">
                                <?php echo e(__('Cadastrar')); ?>

                            </button>
                        </div>
                    </div>

                <?php echo Form::close(); ?>

                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>