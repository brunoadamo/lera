<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="post-list post-list-home">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-9 pt-3 pb-3 d-none d-sm-none d-md-block">
                <h3 class="mb-3">COLABORE CONOSCO!</h3>
                <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $narratives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $narrative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 portfolio-item">
                        <div class="card">
                            <div class="col-sm-12 mx-auto featured" style="background-image: url('<?php echo e(asset(@$narrative->folder  . '' . @$narrative->picture)); ?>')"> </div>
                            <div class="card-body mx-auto text-center">
                                <p class="card-text"><a href="/narrative/<?php echo e($narrative->id); ?>"><?php echo e($narrative->title); ?></a></p>
                                <small> <strong><?php echo e($narrative->kind->title); ?></strong> - <?php echo e($narrative->acts_count); ?> / <?php echo e($narrative->act_n); ?> Atos </small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="row">
                        <div class="col-sm-12 mx-auto">
                            <p>Nenhuma narrativa cadastrada</p>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-sm-12 mt-3">
                    <a href="/narratives" class="btn btn-warning font-weight-light"><small><strong>Veja mais</strong></small></a>
                </div>
                </div>
            </div>
            

            <div class="col-sm-12 col-lg-3 pt-3 pb-3 side-card">
                <h4 class="mb-2 text-left">Conheça algumas narrativas...</h4>
                <hr>
                <div class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $narratives_full; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $narrative_full): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


                    <a href="/narrative/<?php echo e($narrative_full->id); ?>" class="list-group-item list-group-item-action flex-column align-items-start p-1 pb-3">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1"><?php echo e($narrative_full->title); ?></h6>
                        </div>
                        <p class="mb-1"><?php echo e($narrative_full->theme); ?></p>
                        <small><?php echo e($narrative_full->kind->title); ?></small>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="row">
                            <div class="col-sm-12 mx-auto">
                                <p>Nenhuma narrativa cadastrada</p>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="col-sm-12 mt-3 text-center">
                    <a href="/portfolio" class="btn btn-warning font-weight-light"><small><strong>Veja mais</strong></small></a>
                </div>
            </div>
        </div>
        <div class="clearfix mb-3"></div>

    </div>
</div>

<div class="about bg-light-grey" id="sobre">
    <div class="container">
        <div class="row">

            <div class="col-sm-10 mx-auto pt-5 pb-5">

                <h3>Conheça o Lera</h3>

                <div class="">
                    <p>
                        O LERA é parte de um projeto de Trabalho de Graduação 2018 do curso Análise e Desenvolvimento de Sistemas da Faculdade de Tecnologia de Indaiatuba (FATEC-ID). 
                    </p>
                    <p>
                        O objetivo do LERA é incentivar as práticas de leitura e escrita, por meio de narrativas colaborativas.
                        
                    </p>
                    <p>Foram utilizados conceitos chave como: a importância da leitura, inclusão social, escrita e cidadania, e redes colaborativas, que sustentam a pesquisa os quais são ancorados em práticas de pesquisas apresentadas em um conjunto de trabalhos relacionados.</p>
                    <p>Para conhecer mais sobre o trabalho clique <a href="">aqui</a></p>
                    <p>Nos ajude avaliando essa aplicação, sua opinião vale muito =)</p>

                    <a href="https://goo.gl/forms/VEIIpdGEoigrS03D2" class="btn btn-warning" target="_blank">Diga o que achou do LERA!</a>
                </div>
            </div>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>