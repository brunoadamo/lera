<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h1 class="text-center"><?php echo e(__('Nova senha')); ?></h1>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('password.email')); ?>" aria-label="<?php echo e(__('Nova senha')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <div class="form-group floating-label-form-group controls">
                            <label for="email"><?php echo e(__('E-mail')); ?></label>

                            <input id="email" type="email" placeholder="<?php echo e(__('E-mail')); ?>" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        </div>
                        <?php if($errors->has('email')): ?>
                            <p class="help-block text-danger"><?php echo e($errors->first('email')); ?></p>
                        <?php endif; ?>
                    </div> 
                    <div class="form-group row mb-0">
                        <div class="col-md-12 mx-auto">
                            <button type="submit" class="btn btn-warning">
                                <?php echo e(__('Enviar link para nova senha')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>