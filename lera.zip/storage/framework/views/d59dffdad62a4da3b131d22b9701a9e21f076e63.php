<?php $__empty_1 = true; $__currentLoopData = $narratives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $narrative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
        <div class="col-sm-10 mx-auto featured" style="background-image: url('<?php echo e(asset(@$narrative->folder  . '' . @$narrative->picture)); ?>')"> </div>
        <div class="col-sm-10 mx-auto">
            <div class="post-preview">
                <a href="/narrative/<?php echo e($narrative->id); ?>">
                    <h2 class="post-title">
                        <?php echo e($narrative->title); ?>

                    </h2>
                </a>
                <p class="post-meta"><strong><?php echo e($narrative->kind->title); ?></strong> - Criado por
                    <strong><?php echo e($narrative->user->alias); ?>  </strong>
                    em <?php echo e($narrative->created_at->format('d/m/Y')); ?>


                    
                    <small class="float-right"><?php echo e($narrative->acts_count); ?> / <?php echo e($narrative->act_n); ?> Atos</small>
                </p>
                
            </div>
        </div>
            
    </div>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="row">
        <div class="col-sm-12 mx-auto">
            <p>Nenhuma narrativa cadastrada</p>
        </div>
    </div>
<?php endif; ?>

    <!-- Pager -->
    <?php echo e($narratives->links()); ?>

    <!-- Pager -->