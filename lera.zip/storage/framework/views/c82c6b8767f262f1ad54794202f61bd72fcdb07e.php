<?php $__env->startSection('content'); ?>

<?php ($colaborates = []); ?>
<?php ($colaborates_id = array()); ?>
<?php ($user_id = 0); ?>
<?php if(Auth::check()): ?>
    <?php ($user_id = Auth::user()->id); ?>
<?php endif; ?>

<?php $__currentLoopData = $colaborate->acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($colaborates_id[] = $act->user->id); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Post Content -->
<article>
    <div class="narrative-single">
        <div class="container">

            <?php if($user_id == $narrative->user->id): ?>
                <div class="row ">
                    <div class="col-lg-8 col-md-10 mx-auto">
                        <div class="row ">
                            <div class="col-sm-10 pb-2">
                            <h5><?php echo e(Auth::user()->alias); ?>! Você criou essa narrativa =)</h5>
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url("/admin/narratives/" . $narrative->id . "/edit")); ?>" class="btn btn-info btn-sm float-right font-weight-normal mr-3"> Editar </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                
                <div class="col-lg-8 col-md-10 mx-auto">
                    <p><?php echo $narrative->content; ?></p>
                    <?php ($count_act = 1); ?>
                    <?php $__currentLoopData = $narrative->acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($count_act++); ?>
                            <div class="card mb-4">
                                <div class="card-header">
                                    <?php echo e($count_act); ?>º Ato
                                </div>
                                <div class="card-body">
                                    <p class="blockquote mb-0">
                                    <p><?php echo $act->content; ?></p>
                                    <p class="blockquote-footer">Escrito por <cite title="<?php echo $act->user->alias; ?>"><?php echo $act->user->alias; ?></cite></footer>
                                    </p>
                                </div>
                            </div>
                            <?php ($colaborates[] =  $act->user->alias); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(Auth::check()): ?>
                        <?php ($user_id = Auth::user()->id); ?>
                        <?php if($user_id == $narrative->user->id): ?>
                            <?php $__currentLoopData = $colaborate->acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <?php if($act->status == 0): ?>
                                    <div class="card mb-2">
                                        <div class="card-header">
                                            <ul class="nav nav-pills card-header-pills">
                                                <li class="nav-item">
                                                    <a class="nav-link active btn-success" href="<?php echo e(url("admin/acts/{$act->id}/status/1")); ?>" data-method="PUT" data-token="<?php echo e(csrf_token()); ?>">Aprovar</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a href="<?php echo e(url("admin/acts/{$act->id}/status/99")); ?>" data-method="PUT" data-token="<?php echo e(csrf_token()); ?>" class="nav-link">Rejeitar</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="card-body">
                                            <blockquote class="blockquote mb-0">
                                            <p><?php echo $act->content; ?></p>
                                            <p class="blockquote-footer">Criado por <cite title="<?php echo e($act->user->alias); ?>"><?php echo e($act->user->alias); ?></cite></p>
                                            </blockquote>
                                        </div>
                                    </div>
                                    
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>                
                        <?php $__currentLoopData = $colaborate->acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($act->status == 0 && $user_id == $act->user->id): ?>
                                <div class="card mb-2">
                                    <div class="card-header">
                                        <ul class="nav nav-pills card-header-pills">
                                            <li class="nav-item">
                                               
                                                <a href="<?php echo e(url("/admin/acts/" .$act->id . "/edit/" . $narrative->id)); ?>" class="nav-link active btn-info"> Editar </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card-body">
                                        <blockquote class="blockquote mb-0">
                                        <?php echo $act->content; ?>

                                        <p class="blockquote-footer">Criado por <cite title="<?php echo e($act->user->alias); ?>"><?php echo e($act->user->alias); ?></cite></p>
                                        </blockquote>
                                    </div>
                                </div>
                                
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                    
                    <?php endif; ?>        
                    
                        

                        
                    <?php if(!in_array($user_id, $colaborates_id) && $user_id != $narrative->user->id && !$narrative->is_published): ?>
                        <div class="row col-sm-12 mx-auto text-center mb-5 mt-5">
                            <a href="<?php echo e(url('narrative/'. $narrative->id . '/acts/create')); ?>" class="btn btn-warning mx-auto">Colabore com essa narrativa!</a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</article>

<?php if($narrative->is_published): ?>
<session>
    <div class="comments">
        <div class="container">

            <?php if(Auth::check()): ?>
                <div class="row">
                    <div class="col-lg-8 col-md-10 mx-auto">
                        <!-- Comments Form -->
                        <div class="card my-4">
                            <h3 class="card-header">Comentários:</h3>
                            <div class="card-body">
                                <form method="POST" action="/narrative/<?php echo e($narrative->id); ?>/comment" aria-label="<?php echo e(__('Comentário')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <textarea id="content" name="content" class="form-control" rows="3"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <h4 class="text-center">Faça o login para comentar!</h4>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-8 col-md-10 mx-auto">
                    <!-- Single Comment -->
                    <?php $__empty_1 = true; $__currentLoopData = $narrative->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="row">
                        <div class="col-sm-12 media mb-4 pb-4 border-bottom">
                            <div class="col-2 col-sm-1 user img-thumbnail" style="background-image: url(<?php echo e(asset(@$comment->user->folder  . '' . @$comment->user->picture)); ?>);">
                            </div>
                            <div class="col-10 col-sm-11">
                                <div class="media-body">
                                    <h5 class="mt-0">
                                        <?php echo e($comment->user->alias); ?>

                                        <small class="float-right"><?php echo e($comment->created_at->format('d/m/Y')); ?></small>

                                    </h5>
                                    <?php echo e($comment->content); ?>

                                </div>
                                <?php if(Auth::user()->id == $comment->user->id): ?>
                                    <div class="control-buttons pt-3">

                                        <a href="<?php echo e(url("/admin/comments/{$comment->id}")); ?>" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-confirm="Deseja excluir?" class="text-danger">Delete</a>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="media mb-4">
                        <div class="media-body">
                            Nenhum comentário até o momento...
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</session>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default_narrative', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>