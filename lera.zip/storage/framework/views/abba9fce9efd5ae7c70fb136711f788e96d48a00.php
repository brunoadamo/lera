<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <label for="picture"><?php echo e(__('Capa da Narrativa')); ?></label>
        <input id="picture" type="file" placeholder="<?php echo e(__('Nome')); ?>" class="form-control<?php echo e($errors->has('picture') ? ' is-invalid' : ''); ?>" name="picture" value="<?php echo e(old('picture')); ?>" autofocus>

        <?php if($errors->has('picture')): ?>
            <p class="help-block text-danger"><?php echo e($errors->first('picture')); ?></p>
        <?php endif; ?>
    </div>
</div>

<div class="form-group">
    <div class="form-group floating-label-form-group controls">
        <?php echo Form::label('title', 'Título', ['class' => 'col-md-2 control-label']); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'Título', 'required', 'autofocus']); ?>

        
    </div>
    <?php if($errors->has('title')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('title')); ?></p>
    <?php endif; ?>
</div>

<div class="form-row">

    <div class="form-group col-sm-8">
        <div class="form-group floating-label-form-group controls">
          
            <?php echo Form::select('kind_id', $kinds, null, ['class' => 'form-control', 'placeholder' => 'Tema', 'required', 'autofocus']); ?>

    
        </div>
        <?php if($errors->has('kind_id')): ?>
            <p class="help-block text-danger"><?php echo e($errors->first('kind_id')); ?></p>
        <?php endif; ?>
    </div>

    <div class="form-group col-sm-4">
        <div class="form-group floating-label-form-group controls">
            <?php echo Form::selectRange('act_n', 1, 5, '', ['class' => 'form-control', 'placeholder' => 'Quantidade de atos', 'required', 'autofocus']); ?>

    
        </div>
        <?php if($errors->has('act_n')): ?>
            <p class="help-block text-danger"><?php echo e($errors->first('act_n')); ?></p>
        <?php endif; ?>
    </div>
    
</div>

<div class="form-group">
    <?php echo Form::label('clue', 'Dica de continuidade da narrativa', ['class' => 'col-md-12 control-label']); ?>

    <?php echo Form::textarea('clue', null, ['class' => 'form-control summernote', 'placeholder' => 'Dica', 'required', 'autofocus']); ?>


    <?php if($errors->has('clue')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('clue')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group">
    <?php echo Form::label('content', '1º Ato', ['class' => 'col-md-12 control-label']); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control summernote', 'placeholder' => '1º Ato', 'required', 'autofocus']); ?>


    <?php if($errors->has('content')): ?>
        <p class="help-block text-danger"><?php echo e($errors->first('content')); ?></p>
    <?php endif; ?>
</div>