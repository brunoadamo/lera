<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 class="text-center"><?php echo e(__('Login')); ?></h1>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <div class="form-group">
                        <div class="form-group floating-label-form-group controls">
                            <label for="email"><?php echo e(__('E-mail')); ?></label>

                            <input id="email" type="email" placeholder="<?php echo e(__('E-mail')); ?>" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        </div>
                        <?php if($errors->has('email')): ?>
                            <p class="help-block text-danger"><?php echo e($errors->first('email')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <div class="form-group floating-label-form-group controls">
                            <label for="password"><?php echo e(__('Senha')); ?></label>

                            <input id="password" type="password" placeholder="<?php echo e(__('Senha')); ?>" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>" required autofocus>

                           
                        </div>
                        <?php if($errors->has('password')): ?>
                            <p class="help-block text-danger"><?php echo e($errors->first('password')); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        </div>
                    </div>

                    <div class="row">

                        <div class="col-sm-4">

                            <div class="form-group">
                                <button type="submit" class="btn btn-warning">
                                    <?php echo e(__('Login')); ?>

                                </button>   
                            </div>
                        </div>

                        <div class="col-sm-8 mx-auto">
                            <div class="form-group">
                                <a class="btn btn-link float-right" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Esqueceu sua senha?')); ?>

                                </a>
                                <a class="btn btn-link float-right mr-5" href="<?php echo e(route('register')); ?>">
                                    <?php echo e(__('Cadastre-se')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                   
                    

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>