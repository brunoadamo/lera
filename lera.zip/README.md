# lera
Project developed for the conclusion of the course Analysis and Systems Development
