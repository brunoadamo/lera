
@include('includes.head')

@include('includes.nav')

@include('includes.header')

@yield('content')

@include('includes.footer')