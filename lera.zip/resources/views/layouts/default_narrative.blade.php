
@include('includes.head')

@include('includes.nav')

@include('includes.header_narrative')

@yield('content')

@include('includes.footer')